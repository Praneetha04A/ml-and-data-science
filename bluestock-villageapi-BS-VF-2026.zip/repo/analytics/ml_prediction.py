"""
Simple RandomForest baseline for predicting next-period fund performance
from engineered features (rolling volatility, momentum, expense ratio, etc.).

This is a starting point (poster section 9's "bonus challenge" ML model) —
swap in your real feature set and label once fund_metrics/nav_history are
populated in Postgres.
"""
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error


def train_baseline_model(df: pd.DataFrame, feature_cols: list[str], target_col: str):
    X = df[feature_cols]
    y = df[target_col]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    predictions = model.predict(X_test)
    mae = mean_absolute_error(y_test, predictions)

    return model, mae


if __name__ == "__main__":
    # Synthetic demo dataset so the script is runnable standalone.
    rng = np.random.default_rng(0)
    n = 300
    demo = pd.DataFrame({
        "rolling_vol_30d": rng.uniform(0.01, 0.05, n),
        "momentum_90d": rng.uniform(-0.1, 0.2, n),
        "expense_ratio": rng.uniform(0.2, 1.6, n),
        "aum_cr": rng.uniform(500, 5000, n),
    })
    # Synthetic label: next-quarter return, loosely correlated with momentum
    demo["next_qtr_return"] = (
        0.5 * demo["momentum_90d"] - 0.3 * demo["rolling_vol_30d"]
        + rng.normal(0, 0.02, n)
    )

    features = ["rolling_vol_30d", "momentum_90d", "expense_ratio", "aum_cr"]
    model, mae = train_baseline_model(demo, features, "next_qtr_return")
    print(f"Trained RandomForestRegressor on {n} synthetic samples")
    print(f"Test MAE: {mae:.4f}")
    print(f"Feature importances: {dict(zip(features, model.feature_importances_.round(3)))}")
