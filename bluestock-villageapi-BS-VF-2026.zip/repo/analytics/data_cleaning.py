"""
Data cleaning & feature engineering for raw NAV / fund feed exports.
Matches poster section 9's cleaning snippets, expanded into a reusable module.
"""
import pandas as pd


def load_and_clean(csv_path: str) -> pd.DataFrame:
    df = pd.read_csv(csv_path)

    # Normalize types
    if "date" in df.columns:
        df["date"] = pd.to_datetime(df["date"], errors="coerce")
    if "amount" in df.columns:
        df["amount"] = df["amount"].astype(str).str.replace(",", "").astype(float)

    # Drop exact duplicate rows and rows missing a scheme identifier
    df = df.drop_duplicates()
    if "scheme_name" in df.columns:
        df = df.dropna(subset=["scheme_name"])

    return df


def pivot_scheme_returns(df: pd.DataFrame) -> pd.DataFrame:
    """Wide-format pivot: one column per scheme, indexed by date."""
    pivot = df.pivot_table(values="return", index="date", columns="scheme_name", aggfunc="last")
    return pivot.fillna(0)


def feature_engineer(df: pd.DataFrame) -> pd.DataFrame:
    """Add rolling volatility and momentum features used by the ML model."""
    df = df.sort_values("date").copy()
    df["rolling_vol_30d"] = df.groupby("scheme_name")["return"].transform(
        lambda s: s.rolling(30, min_periods=5).std()
    )
    df["momentum_90d"] = df.groupby("scheme_name")["return"].transform(
        lambda s: s.rolling(90, min_periods=10).sum()
    )
    return df


if __name__ == "__main__":
    print("This module expects a raw NAV/returns CSV with columns: "
          "date, scheme_name, return, amount. Import and call load_and_clean(path).")
