"""
Financial analytics module for the Bluestock Mutual Fund platform.

Computes the risk/return metrics shown in poster section 4:
daily returns, CAGR, Sharpe, Sortino, Alpha/Beta, Max Drawdown, VaR(95%),
Rolling Sharpe, Sector Drift, and Tracking Error.

Run standalone with `python financial_metrics.py` to see a demo on synthetic NAV data.
"""
import numpy as np
import pandas as pd

TRADING_DAYS = 252


def daily_returns(nav: pd.Series) -> pd.Series:
    """r_t = (P_t - P_{t-1}) / P_{t-1}"""
    return nav.pct_change().dropna()


def cagr(nav: pd.Series, years: float) -> float:
    """((End / Start) ** (1/years) - 1) * 100"""
    return ((nav.iloc[-1] / nav.iloc[0]) ** (1 / years) - 1) * 100


def sharpe_ratio(returns: pd.Series, risk_free_annual: float = 0.065) -> float:
    """(Rp - Rf) / Std(Rp), annualized."""
    rf_daily = risk_free_annual / TRADING_DAYS
    excess = returns - rf_daily
    if excess.std() == 0:
        return np.nan
    return (excess.mean() / excess.std()) * np.sqrt(TRADING_DAYS)


def sortino_ratio(returns: pd.Series, risk_free_annual: float = 0.065) -> float:
    """(Rp - Rf) / DownsideStd(Rp), annualized."""
    rf_daily = risk_free_annual / TRADING_DAYS
    excess = returns - rf_daily
    downside = excess[excess < 0]
    downside_std = downside.std()
    if not downside_std or np.isnan(downside_std) or downside_std == 0:
        return np.nan
    return (excess.mean() / downside_std) * np.sqrt(TRADING_DAYS)


def alpha_beta(fund_returns: pd.Series, benchmark_returns: pd.Series) -> tuple[float, float]:
    """CAPM: regress fund returns on benchmark returns -> (alpha_annualized, beta)."""
    aligned = pd.concat([fund_returns, benchmark_returns], axis=1).dropna()
    aligned.columns = ["fund", "bench"]
    cov = np.cov(aligned["fund"], aligned["bench"])
    beta = cov[0, 1] / cov[1, 1]
    alpha_daily = aligned["fund"].mean() - beta * aligned["bench"].mean()
    alpha_annualized = alpha_daily * TRADING_DAYS * 100
    return round(alpha_annualized, 3), round(beta, 3)


def max_drawdown(nav: pd.Series) -> float:
    """(P_max - P_min) / P_max over the running peak, expressed as a negative %."""
    running_max = nav.cummax()
    drawdown = (nav - running_max) / running_max
    return round(drawdown.min() * 100, 2)


def value_at_risk(returns: pd.Series, confidence: float = 0.95) -> float:
    """Historical VaR: the loss threshold not exceeded with `confidence` probability."""
    return round(np.percentile(returns, (1 - confidence) * 100) * 100, 2)


def rolling_sharpe(returns: pd.Series, window: int = 63) -> pd.Series:
    """Rolling Sharpe over a trading-day window (default ~1 quarter)."""
    roll_mean = returns.rolling(window).mean()
    roll_std = returns.rolling(window).std()
    return (roll_mean / roll_std) * np.sqrt(TRADING_DAYS)


def sector_drift(portfolio_weights: dict, benchmark_weights: dict) -> dict:
    """w_p - w_b per sector."""
    sectors = set(portfolio_weights) | set(benchmark_weights)
    return {
        s: round(portfolio_weights.get(s, 0) - benchmark_weights.get(s, 0), 4)
        for s in sectors
    }


def tracking_error(fund_returns: pd.Series, benchmark_returns: pd.Series) -> float:
    """Std(Rp - Rb) * sqrt(252)."""
    diff = (fund_returns - benchmark_returns).dropna()
    return round(diff.std() * np.sqrt(TRADING_DAYS) * 100, 2)


def composite_score(rank_return: float, rank_sharpe: float, rank_alpha: float,
                     rank_expense_inv: float, rank_drawdown_inv: float) -> float:
    """
    30% x 3yr return rank + 25% x Sharpe rank + 20% x Alpha rank
    + 15% x expense ratio rank (inverted) + 10% x max drawdown rank (inverted)
    Each rank input should already be normalized 0-100.
    """
    score = (0.30 * rank_return + 0.25 * rank_sharpe + 0.20 * rank_alpha
             + 0.15 * rank_expense_inv + 0.10 * rank_drawdown_inv)
    return round(score, 2)


if __name__ == "__main__":
    # Demo on synthetic NAV data so the script runs standalone without a DB connection.
    rng = np.random.default_rng(42)
    dates = pd.date_range("2023-01-01", periods=500, freq="B")
    fund_nav = pd.Series(100 * (1 + rng.normal(0.0007, 0.011, len(dates))).cumprod(), index=dates)
    bench_nav = pd.Series(100 * (1 + rng.normal(0.0005, 0.010, len(dates))).cumprod(), index=dates)

    fret, bret = daily_returns(fund_nav), daily_returns(bench_nav)
    years = len(dates) / TRADING_DAYS

    print(f"CAGR:            {cagr(fund_nav, years):.2f}%")
    print(f"Sharpe:          {sharpe_ratio(fret):.2f}")
    print(f"Sortino:         {sortino_ratio(fret):.2f}")
    a, b = alpha_beta(fret, bret)
    print(f"Alpha / Beta:    {a}% / {b}")
    print(f"Max Drawdown:    {max_drawdown(fund_nav)}%")
    print(f"VaR (95%):       {value_at_risk(fret)}%")
    print(f"Tracking Error:  {tracking_error(fret, bret)}%")
