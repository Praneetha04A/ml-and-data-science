# Bluestock Mutual Fund & VillageAPI Capstone Synergy

**Project ID:** BS-VF-2026
**Team:** Praneetha Mannuru (Lead), Poorvi Balakrishnan, Anushka S, Karthik KJ, Geetha Boddu

A production-grade financial intelligence system for the Nifty 100 mutual funds, paired with a
SaaS REST API delivering India's complete, live village-level address hierarchy to B2B partners.

## Repo layout

```
backend/      Node.js + Express REST API (funds, schemes, performance, analytics, address hierarchy)
frontend/     React SPA — Admin dashboard, B2B portal, demo client
analytics/    Python scripts — financial metrics, data cleaning, ML prediction
sql/          PostgreSQL schema (address hierarchy + fund tables)
powerbi/      DAX measures reference for the Power BI dashboards
docs/         API specification
```

## Quick start

### Backend
```bash
cd backend
npm install
cp .env.example .env
npm run dev
```
API runs on `http://localhost:4000`. All endpoints require an `X-API-Key` header — the demo key
`demo-readonly-key` is preloaded and rate-limited to 100 requests/day.

### Frontend
```bash
cd frontend
npm install
npm start
```

### Analytics
```bash
cd analytics
pip install -r requirements.txt
python financial_metrics.py
```

### Database
Run `sql/schema.sql` against a PostgreSQL 14+ instance to create the address hierarchy and fund
tables. The backend currently reads from the bundled JSON fixtures in `backend/data/` so it runs
without a live DB; swap in `pg` queries (stubbed in `backend/db.js`) once your Postgres instance
is ready.

## Tech stack
- **Backend:** Node.js, Express.js, Redis (rate limiting), JWT (admin auth)
- **Database:** PostgreSQL
- **Frontend:** React
- **Analytics/ML:** Python (pandas, statsmodels, scikit-learn)
- **BI:** Power BI (DirectQuery over PostgreSQL)
- **Deployment:** Docker, Railway
