// Central place to configure the API base URL and demo key used by every page.
export const API_BASE = process.env.REACT_APP_API_BASE || 'http://localhost:4000/api/v1';
export const API_KEY = process.env.REACT_APP_API_KEY || 'demo-readonly-key';

export async function apiGet(path) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { 'X-API-Key': API_KEY },
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Request failed (${res.status})`);
  }
  return res.json();
}
