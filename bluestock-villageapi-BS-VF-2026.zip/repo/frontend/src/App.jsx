import React from 'react';
import { HashRouter, Routes, Route, NavLink } from 'react-router-dom';
import AdminDashboard from './pages/AdminDashboard';
import B2BPortal from './pages/B2BPortal';
import DemoClient from './pages/DemoClient';

export default function App() {
  return (
    <HashRouter>
      <div className="app-shell">
        <aside className="sidebar">
          <h1>Bluestock &amp; VillageAPI</h1>
          <div className="lead">BS-VF-2026</div>
          <nav>
            <NavLink to="/" end className={({ isActive }) => (isActive ? 'active' : '')}>
              Admin Dashboard
            </NavLink>
            <NavLink to="/b2b" className={({ isActive }) => (isActive ? 'active' : '')}>
              B2B Portal
            </NavLink>
            <NavLink to="/demo" className={({ isActive }) => (isActive ? 'active' : '')}>
              Demo / Contact
            </NavLink>
          </nav>
        </aside>
        <main className="main">
          <Routes>
            <Route path="/" element={<AdminDashboard />} />
            <Route path="/b2b" element={<B2BPortal />} />
            <Route path="/demo" element={<DemoClient />} />
          </Routes>
        </main>
      </div>
    </HashRouter>
  );
}
