import React from 'react';

export default function FundTable({ funds }) {
  return (
    <table>
      <thead>
        <tr>
          <th>Scheme</th>
          <th>Type</th>
          <th>AUM (Cr)</th>
          <th>CAGR 3Y</th>
          <th>Sharpe</th>
          <th>Score</th>
        </tr>
      </thead>
      <tbody>
        {funds.map((f) => (
          <tr key={f.id}>
            <td>{f.scheme_name}</td>
            <td>{f.scheme_type}</td>
            <td>₹{f.aum_cr?.toLocaleString('en-IN')}</td>
            <td>{f.cagr_3y}%</td>
            <td>{f.sharpe}</td>
            <td>{f.score}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
