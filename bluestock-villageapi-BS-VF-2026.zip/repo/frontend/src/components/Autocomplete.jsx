import React, { useState } from 'react';
import { apiGet } from '../api';

export default function Autocomplete() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  async function search(e) {
    e.preventDefault();
    if (!query.trim()) return;
    setLoading(true);
    setError(null);
    try {
      const data = await apiGet(`/addresses/autocomplete?q=${encodeURIComponent(query)}`);
      setResults(data.results);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="panel">
      <h3 style={{ marginTop: 0 }}>Village address lookup</h3>
      <form className="search-box" onSubmit={search}>
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search a village, e.g. Hebbal"
        />
        <button className="btn" type="submit">{loading ? 'Searching…' : 'Search'}</button>
      </form>
      {error && <p style={{ color: '#b3261e', fontFamily: 'sans-serif' }}>{error}</p>}
      {results.map((r, i) => (
        <div className="result-item" key={i}>
          {r.village}, {r.sub_district}, {r.district}, {r.state}
          <span className="pill">{r.pincode}</span>
        </div>
      ))}
      {!loading && !error && results.length === 0 && query && (
        <p style={{ fontFamily: 'sans-serif', color: '#5b6478' }}>No matches yet — try another village name.</p>
      )}
    </div>
  );
}
