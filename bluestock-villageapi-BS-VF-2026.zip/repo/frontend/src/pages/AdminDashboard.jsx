import React, { useEffect, useState } from 'react';
import { apiGet } from '../api';
import FundTable from '../components/FundTable';

export default function AdminDashboard() {
  const [analytics, setAnalytics] = useState(null);
  const [funds, setFunds] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    Promise.all([apiGet('/analytics'), apiGet('/funds')])
      .then(([a, f]) => {
        setAnalytics(a);
        setFunds(f.results);
      })
      .catch((err) => setError(err.message));
  }, []);

  return (
    <div>
      <h2>Admin Dashboard</h2>
      <p className="sub">
        Live view over the Nifty 100 fund universe — AUM, SIP inflows, and the composite
        scorecard ranking.
      </p>

      {error && (
        <div className="panel">
          <p style={{ fontFamily: 'sans-serif', color: '#b3261e' }}>
            Couldn't reach the API: {error}. Make sure the backend is running on
            <code> localhost:4000</code>.
          </p>
        </div>
      )}

      {analytics && (
        <div className="stat-row">
          <div className="stat-card">
            <div className="value">₹{analytics.total_aum_cr.toLocaleString('en-IN')} Cr</div>
            <div className="label">Total AUM</div>
          </div>
          <div className="stat-card">
            <div className="value">₹{analytics.sip_inflows_ytd_cr.toLocaleString('en-IN')} Cr</div>
            <div className="label">SIP Inflows (YTD)</div>
          </div>
          <div className="stat-card">
            <div className="value">{analytics.unique_investors_cr} Cr</div>
            <div className="label">Unique Investors</div>
          </div>
          <div className="stat-card">
            <div className="value">{analytics.active_schemes}</div>
            <div className="label">Active Schemes</div>
          </div>
        </div>
      )}

      <div className="panel">
        <h3 style={{ marginTop: 0 }}>All schemes</h3>
        {funds.length > 0 ? <FundTable funds={funds} /> : !error && <p>Loading…</p>}
      </div>
    </div>
  );
}
