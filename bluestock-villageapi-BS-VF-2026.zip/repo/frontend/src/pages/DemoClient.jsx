import React, { useState } from 'react';

export default function DemoClient() {
  const [submitted, setSubmitted] = useState(false);

  function handleSubmit(e) {
    e.preventDefault();
    // Hook this up to your backend contact-form endpoint or an email service.
    setSubmitted(true);
  }

  return (
    <div>
      <h2>Request API access</h2>
      <p className="sub">
        Tell us about your use case and we'll issue a paid-tier API key.
      </p>

      <div className="panel">
        {submitted ? (
          <p style={{ fontFamily: 'sans-serif' }}>
            Thanks — your request has been received. We'll follow up by email with your API key.
          </p>
        ) : (
          <form className="contact-form" onSubmit={handleSubmit}>
            <label htmlFor="name">Name</label>
            <input id="name" required />

            <label htmlFor="company">Company</label>
            <input id="company" required />

            <label htmlFor="email">Work email</label>
            <input id="email" type="email" required />

            <label htmlFor="usecase">What will you use the API for?</label>
            <textarea id="usecase" rows={4} />

            <button className="btn" type="submit" style={{ marginTop: 18 }}>
              Submit request
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
