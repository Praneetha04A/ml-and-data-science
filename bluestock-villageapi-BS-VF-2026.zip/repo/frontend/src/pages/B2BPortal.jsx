import React, { useEffect, useState } from 'react';
import { apiGet } from '../api';
import Autocomplete from '../components/Autocomplete';

export default function B2BPortal() {
  const [top5, setTop5] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    apiGet('/analytics')
      .then((a) => setTop5(a.top_5_by_score))
      .catch((err) => setError(err.message));
  }, []);

  return (
    <div>
      <h2>B2B Portal</h2>
      <p className="sub">
        Self-serve access to fund rankings and the India address hierarchy API,
        using your issued API key.
      </p>

      <Autocomplete />

      <div className="panel">
        <h3 style={{ marginTop: 0 }}>Top 5 funds by composite score</h3>
        {error && <p style={{ fontFamily: 'sans-serif', color: '#b3261e' }}>{error}</p>}
        <ol style={{ fontFamily: 'sans-serif', fontSize: '0.92rem' }}>
          {top5.map((f) => (
            <li key={f.id} style={{ marginBottom: 6 }}>
              {f.scheme_name} — score {f.score}, Sharpe {f.sharpe}
            </li>
          ))}
        </ol>
      </div>
    </div>
  );
}
