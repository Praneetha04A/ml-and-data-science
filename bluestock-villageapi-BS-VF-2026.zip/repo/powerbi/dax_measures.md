# Power BI DAX Measures — Bluestock Mutual Fund Dashboards

Connection: PostgreSQL via DirectQuery, `Funds`, `NavHistory`, `SipFlows`, `FundMetrics` tables.

## Core measures

```dax
Total AUM = SUM('Funds'[AUM])

Total SIP Inflow YTD = SUM('SipFlows'[sip_inflow_cr])

Unique Investors = SUM('SipFlows'[unique_investors])

Active Schemes = DISTINCTCOUNT('Funds'[scheme_id])

Top_Scheme = TOPN(1, 'Funds', [1Y Return], DESC)

Avg Sharpe Ratio = AVERAGE('FundMetrics'[sharpe])

1Y Return =
VAR StartNav = CALCULATE(MIN('NavHistory'[nav]), DATESINPERIOD('NavHistory'[nav_date], MAX('NavHistory'[nav_date]), -1, YEAR))
VAR EndNav = CALCULATE(MAX('NavHistory'[nav]), LASTDATE('NavHistory'[nav_date]))
RETURN DIVIDE(EndNav - StartNav, StartNav)

SIP Continuity Streak =
CALCULATE(
    COUNTROWS('SipFlows'),
    FILTER('SipFlows', 'SipFlows'[sip_inflow_cr] > 0)
)

Composite Score =
0.30 * [Rank Return] + 0.25 * [Rank Sharpe] + 0.20 * [Rank Alpha]
    + 0.15 * [Rank Expense Inv] + 0.10 * [Rank Drawdown Inv]
```

## Dashboard pages (7 total + 1 real-time page)
1. Executive Overview — Total AUM, SIP inflows, investor counts, top schemes
2. Fund Performance — CAGR, Sharpe, Sortino, drawdown by scheme
3. Risk Analytics — VaR, rolling Sharpe, tracking error
4. Sector Allocation & Drift
5. SIP & Investor Trends — continuity flags (6/12/24/36-month)
6. Composite Scorecard & Rankings
7. Address/Geo Analytics — investor counts by state/district (choropleth)
8. **Real-time page** — DirectQuery refresh on a short interval for live AUM ticking

## Pipeline
1. **Connect:** PostgreSQL → Power BI (DirectQuery)
2. **Transform:** Clean, model, build DAX measures & relationships
3. **Build:** 7 dashboards + 1 real-time analytics page
4. **Publish:** Power BI Service (gateway configured, scheduled refresh for non-DirectQuery tables)

Drill-through is enabled from the fund table to a NAV-details page showing holdings and sector allocation.
