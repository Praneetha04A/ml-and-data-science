const express = require('express');
const router = express.Router();
const funds = require('../data/funds.json');

// GET /api/v1/schemes — scheme details (name, house, type, benchmark, expense ratio)
router.get('/', (req, res) => {
  const schemes = funds.map(
    ({ id, scheme_name, fund_house, scheme_type, benchmark, expense_ratio }) => ({
      id,
      scheme_name,
      fund_house,
      scheme_type,
      benchmark,
      expense_ratio,
    })
  );
  res.json({ count: schemes.length, results: schemes });
});

module.exports = router;
