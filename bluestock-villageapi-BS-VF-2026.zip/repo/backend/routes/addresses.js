const express = require('express');
const router = express.Router();
const hierarchy = require('../data/address_hierarchy.json');

// GET /api/v1/addresses/states
router.get('/states', (req, res) => {
  res.json({ states: hierarchy.states.map((s) => s.state) });
});

// GET /api/v1/addresses/districts?state=Karnataka
router.get('/districts', (req, res) => {
  const { state } = req.query;
  if (!state) return res.status(400).json({ error: 'state query param required' });
  const match = hierarchy.states.find((s) => s.state.toLowerCase() === state.toLowerCase());
  if (!match) return res.status(404).json({ error: 'State not found' });
  res.json({ state: match.state, districts: match.districts.map((d) => d.district) });
});

// GET /api/v1/addresses/sub-districts?state=Karnataka&district=Bengaluru Urban
router.get('/sub-districts', (req, res) => {
  const { state, district } = req.query;
  if (!state || !district) {
    return res.status(400).json({ error: 'state and district query params required' });
  }
  const s = hierarchy.states.find((x) => x.state.toLowerCase() === state.toLowerCase());
  if (!s) return res.status(404).json({ error: 'State not found' });
  const d = s.districts.find((x) => x.district.toLowerCase() === district.toLowerCase());
  if (!d) return res.status(404).json({ error: 'District not found' });
  res.json({ state: s.state, district: d.district, sub_districts: d.sub_districts.map((sd) => sd.sub_district) });
});

// GET /api/v1/addresses/villages?state=&district=&sub_district=
router.get('/villages', (req, res) => {
  const { state, district, sub_district } = req.query;
  if (!state || !district || !sub_district) {
    return res.status(400).json({ error: 'state, district and sub_district query params required' });
  }
  const s = hierarchy.states.find((x) => x.state.toLowerCase() === state.toLowerCase());
  if (!s) return res.status(404).json({ error: 'State not found' });
  const d = s.districts.find((x) => x.district.toLowerCase() === district.toLowerCase());
  if (!d) return res.status(404).json({ error: 'District not found' });
  const sd = d.sub_districts.find((x) => x.sub_district.toLowerCase() === sub_district.toLowerCase());
  if (!sd) return res.status(404).json({ error: 'Sub-district not found' });
  res.json({ state: s.state, district: d.district, sub_district: sd.sub_district, villages: sd.villages });
});

// GET /api/v1/addresses/autocomplete?q=hebbal — flat fuzzy search across all villages
router.get('/autocomplete', (req, res) => {
  const q = (req.query.q || '').toLowerCase();
  if (!q) return res.json({ results: [] });

  const results = [];
  for (const s of hierarchy.states) {
    for (const d of s.districts) {
      for (const sd of d.sub_districts) {
        for (const v of sd.villages) {
          if (v.village.toLowerCase().includes(q)) {
            results.push({
              state: s.state,
              district: d.district,
              sub_district: sd.sub_district,
              village: v.village,
              pincode: v.pincode,
            });
          }
        }
      }
    }
  }
  res.json({ count: results.length, results: results.slice(0, 10) });
});

module.exports = router;
