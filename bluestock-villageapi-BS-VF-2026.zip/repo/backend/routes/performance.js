const express = require('express');
const router = express.Router();
const funds = require('../data/funds.json');

// GET /api/v1/performance/:id — return risk/return metrics for one fund
router.get('/:id', (req, res) => {
  const f = funds.find((x) => x.id === Number(req.params.id));
  if (!f) return res.status(404).json({ error: 'Fund not found' });

  res.json({
    id: f.id,
    scheme_name: f.scheme_name,
    cagr_3y: f.cagr_3y,
    sharpe: f.sharpe,
    sortino: f.sortino,
    alpha: f.alpha,
    beta: f.beta,
    max_drawdown: f.max_drawdown,
    var_95: f.var_95,
  });
});

module.exports = router;
