const express = require('express');
const router = express.Router();
const funds = require('../data/funds.json');

// GET /api/v1/analytics — aggregated platform-wide insights
router.get('/', (req, res) => {
  const totalAum = funds.reduce((sum, f) => sum + f.aum_cr, 0);
  const totalSip = funds.reduce((sum, f) => sum + f.sip_inflow_ytd_cr, 0);
  const totalInvestors = funds.reduce((sum, f) => sum + f.unique_investors_cr, 0);

  const top5 = [...funds]
    .sort((a, b) => b.score - a.score)
    .slice(0, 5)
    .map(({ id, scheme_name, score, sharpe }) => ({ id, scheme_name, score, sharpe }));

  res.json({
    total_aum_cr: Number(totalAum.toFixed(2)),
    sip_inflows_ytd_cr: Number(totalSip.toFixed(2)),
    unique_investors_cr: Number(totalInvestors.toFixed(2)),
    active_schemes: funds.length,
    top_5_by_score: top5,
  });
});

module.exports = router;
