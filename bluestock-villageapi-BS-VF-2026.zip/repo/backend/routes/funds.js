const express = require('express');
const router = express.Router();
const funds = require('../data/funds.json');

// GET /api/v1/funds — list all mutual funds, optional ?scheme_type= filter
router.get('/', (req, res) => {
  const { scheme_type } = req.query;
  let result = funds;
  if (scheme_type) {
    result = funds.filter(
      (f) => f.scheme_type.toLowerCase() === String(scheme_type).toLowerCase()
    );
  }
  res.json({ count: result.length, results: result });
});

// GET /api/v1/funds/:id
router.get('/:id', (req, res) => {
  const fund = funds.find((f) => f.id === Number(req.params.id));
  if (!fund) return res.status(404).json({ error: 'Fund not found' });
  res.json(fund);
});

module.exports = router;
