const express = require('express');
const router = express.Router();
const hierarchy = require('../data/address_hierarchy.json');

// GET /api/v1/sipcode?pincode=560024 — reverse geocode a pincode to its full address path
router.get('/', (req, res) => {
  const { pincode } = req.query;
  if (!pincode) return res.status(400).json({ error: 'pincode query param required' });

  for (const s of hierarchy.states) {
    for (const d of s.districts) {
      for (const sd of d.sub_districts) {
        const v = sd.villages.find((x) => x.pincode === pincode);
        if (v) {
          return res.json({
            state: s.state,
            district: d.district,
            sub_district: sd.sub_district,
            village: v.village,
            pincode: v.pincode,
          });
        }
      }
    }
  }
  res.status(404).json({ error: 'Pincode not found' });
});

module.exports = router;
