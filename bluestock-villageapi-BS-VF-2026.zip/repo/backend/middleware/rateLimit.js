// Simple in-memory rate limiter, keyed by API key.
// In production this is backed by Redis so limits are shared across instances;
// swap the Map below for redis INCR + EXPIRE calls.
require('dotenv').config();

const DEMO_KEY = process.env.DEMO_API_KEY || 'demo-readonly-key';
const DEMO_LIMIT = Number(process.env.DEMO_KEY_DAILY_LIMIT || 100);

const counters = new Map(); // key -> { count, resetAt }

function rateLimit(req, res, next) {
  const key = req.header('X-API-Key');
  if (key !== DEMO_KEY) return next(); // only the demo key is capped in this stub

  const now = Date.now();
  const entry = counters.get(key);

  if (!entry || now > entry.resetAt) {
    counters.set(key, { count: 1, resetAt: now + 24 * 60 * 60 * 1000 });
    return next();
  }

  if (entry.count >= DEMO_LIMIT) {
    return res.status(429).json({
      error: 'Rate limit exceeded for demo key',
      limit: DEMO_LIMIT,
      resetAt: new Date(entry.resetAt).toISOString(),
    });
  }

  entry.count += 1;
  next();
}

module.exports = rateLimit;
