// API key auth. Every request must carry X-API-Key.
// A valid demo key is read-only and capped at DEMO_KEY_DAILY_LIMIT requests/day.
require('dotenv').config();

const DEMO_KEY = process.env.DEMO_API_KEY || 'demo-readonly-key';

function apiKeyAuth(req, res, next) {
  const key = req.header('X-API-Key');

  if (!key) {
    return res.status(401).json({ error: 'Missing X-API-Key header' });
  }

  if (key === DEMO_KEY) {
    req.auth = { tier: 'demo', readonly: true };
    return next();
  }

  // TODO: look up paid API keys in Postgres (issued via the admin panel)
  // and attach { tier, readonly: false } to req.auth.
  return res.status(403).json({ error: 'Invalid API key' });
}

// JWT auth for the admin panel (separate from the public API-key auth above).
const jwt = require('jsonwebtoken');

function jwtAuth(req, res, next) {
  const header = req.header('Authorization') || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;

  if (!token) {
    return res.status(401).json({ error: 'Missing bearer token' });
  }

  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

module.exports = { apiKeyAuth, jwtAuth };
