// Stubbed Postgres connection pool.
// Once your database is provisioned (see sql/schema.sql), point DATABASE_URL
// at it and swap the JSON-fixture reads in routes/*.js for real queries using
// this pool, e.g.:
//
//   const { rows } = await pool.query('SELECT * FROM funds WHERE scheme_type = $1', [type]);
//
const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

module.exports = pool;
