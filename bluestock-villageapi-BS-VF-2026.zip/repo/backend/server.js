require('dotenv').config();
const express = require('express');
const cors = require('cors');

const { apiKeyAuth } = require('./middleware/auth');
const rateLimit = require('./middleware/rateLimit');

const fundsRouter = require('./routes/funds');
const schemesRouter = require('./routes/schemes');
const performanceRouter = require('./routes/performance');
const analyticsRouter = require('./routes/analytics');
const addressesRouter = require('./routes/addresses');
const sipcodeRouter = require('./routes/sipcode');

const app = express();
app.use(cors());
app.use(express.json());

app.get('/', (req, res) => {
  res.json({
    name: 'Bluestock Mutual Fund & VillageAPI',
    status: 'ok',
    docs: '/docs/API_SPEC.md in the repo root',
  });
});

// All /api/v1 routes require a valid X-API-Key and are subject to rate limiting.
app.use('/api/v1', apiKeyAuth, rateLimit);

app.use('/api/v1/funds', fundsRouter);
app.use('/api/v1/schemes', schemesRouter);
app.use('/api/v1/performance', performanceRouter);
app.use('/api/v1/analytics', analyticsRouter);
app.use('/api/v1/addresses', addressesRouter);
app.use('/api/v1/sipcode', sipcodeRouter);

app.use((req, res) => res.status(404).json({ error: 'Not found' }));

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`API listening on port ${PORT}`));
