# API Specification — Bluestock Mutual Fund & VillageAPI

Base URL: `http://localhost:4000/api/v1` (production: your deployed domain)

## Auth
Every request requires an `X-API-Key` header.

```bash
curl -X GET "http://localhost:4000/api/v1/funds" \
  -H "X-API-Key: demo-readonly-key"
```

The bundled demo key `demo-readonly-key` is read-only and capped at 100 requests/day
(`DEMO_KEY_DAILY_LIMIT` in `.env`). Exceeding it returns `429 Too Many Requests`.

## Endpoints

| Method | Path | Description |
|---|---|---|
| GET | `/funds` | List all mutual funds. Optional `?scheme_type=` filter. |
| GET | `/funds/:id` | Full details for one fund. |
| GET | `/schemes` | Scheme metadata (name, house, type, benchmark, expense ratio). |
| GET | `/performance/:id` | Risk/return metrics for one fund (CAGR, Sharpe, Sortino, Alpha/Beta, Max Drawdown, VaR). |
| GET | `/analytics` | Aggregated platform insights — total AUM, SIP inflows, top 5 by score. |
| GET | `/addresses/states` | List all states. |
| GET | `/addresses/districts?state=` | Districts within a state. |
| GET | `/addresses/sub-districts?state=&district=` | Sub-districts within a district. |
| GET | `/addresses/villages?state=&district=&sub_district=` | Villages + pincodes. |
| GET | `/addresses/autocomplete?q=` | Fuzzy village search, drop-down-ready. |
| GET | `/sipcode?pincode=` | Reverse-geocode a pincode to its full address path. |

## Sample response — drop-down-ready address search

```json
{
  "state": "Karnataka",
  "district": "Bengaluru Urban",
  "sub_district": "Bengaluru North",
  "village": "Hebbal",
  "pincode": "560024"
}
```

## Rate limiting & abuse handling
- Demo key: 100 requests/day, enforced server-side (in-memory here; Redis in production).
- Malicious or malformed requests are rejected with `429` or `400`.
- Paid tiers (Free / Premium / Pro / Unlimited) are issued and managed via the Admin Panel and
  stored in the `api_keys` table (see `sql/schema.sql`).

## Compliance
- No hard-coded credentials — all secrets via environment variables (`.env`, never committed).
- PII (investor counts, contact form submissions) access-restricted and anonymized in aggregate endpoints.
- Every request is logged to `api_usage_log` for audit and rate-limit accounting.
