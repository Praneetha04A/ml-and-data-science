-- Bluestock Mutual Fund & VillageAPI — PostgreSQL schema
-- Run against PostgreSQL 14+

-- ===================== Address hierarchy =====================
CREATE TABLE IF NOT EXISTS states (
    id SERIAL PRIMARY KEY,
    state VARCHAR(100) UNIQUE NOT NULL
);

CREATE TABLE IF NOT EXISTS districts (
    id SERIAL PRIMARY KEY,
    state_id INTEGER NOT NULL REFERENCES states(id) ON DELETE CASCADE,
    district VARCHAR(100) NOT NULL,
    UNIQUE (state_id, district)
);

CREATE TABLE IF NOT EXISTS sub_districts (
    id SERIAL PRIMARY KEY,
    district_id INTEGER NOT NULL REFERENCES districts(id) ON DELETE CASCADE,
    sub_district VARCHAR(100) NOT NULL,
    UNIQUE (district_id, sub_district)
);

CREATE TABLE IF NOT EXISTS address_hierarchy (
    id SERIAL PRIMARY KEY,
    sub_district_id INTEGER NOT NULL REFERENCES sub_districts(id) ON DELETE CASCADE,
    village VARCHAR(100) NOT NULL,
    pincode VARCHAR(10) NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_address_pincode ON address_hierarchy(pincode);
CREATE INDEX IF NOT EXISTS idx_address_village ON address_hierarchy(village);

-- ===================== Mutual fund tables =====================
CREATE TABLE IF NOT EXISTS fund_houses (
    id SERIAL PRIMARY KEY,
    name VARCHAR(150) UNIQUE NOT NULL
);

CREATE TABLE IF NOT EXISTS schemes (
    id SERIAL PRIMARY KEY,
    fund_house_id INTEGER NOT NULL REFERENCES fund_houses(id),
    scheme_name VARCHAR(200) NOT NULL,
    scheme_type VARCHAR(50) NOT NULL,      -- Large Cap, Mid Cap, Small Cap, Index, Sectoral, ELSS, Flexicap...
    benchmark VARCHAR(100) NOT NULL,
    sector VARCHAR(100),
    expense_ratio NUMERIC(5,2) NOT NULL,
    inception_date DATE
);

CREATE TABLE IF NOT EXISTS nav_history (
    id SERIAL PRIMARY KEY,
    scheme_id INTEGER NOT NULL REFERENCES schemes(id) ON DELETE CASCADE,
    nav_date DATE NOT NULL,
    nav NUMERIC(12,4) NOT NULL,
    UNIQUE (scheme_id, nav_date)
);

CREATE INDEX IF NOT EXISTS idx_nav_scheme_date ON nav_history(scheme_id, nav_date);

CREATE TABLE IF NOT EXISTS sip_flows (
    id SERIAL PRIMARY KEY,
    scheme_id INTEGER NOT NULL REFERENCES schemes(id) ON DELETE CASCADE,
    flow_date DATE NOT NULL,
    sip_inflow_cr NUMERIC(12,2) NOT NULL,
    unique_investors INTEGER
);

CREATE TABLE IF NOT EXISTS fund_metrics (
    id SERIAL PRIMARY KEY,
    scheme_id INTEGER NOT NULL REFERENCES schemes(id) ON DELETE CASCADE,
    as_of_date DATE NOT NULL,
    aum_cr NUMERIC(14,2),
    cagr_3y NUMERIC(6,2),
    sharpe NUMERIC(6,3),
    sortino NUMERIC(6,3),
    alpha NUMERIC(6,3),
    beta NUMERIC(6,3),
    max_drawdown NUMERIC(6,2),
    var_95 NUMERIC(6,2),
    score NUMERIC(5,2),
    UNIQUE (scheme_id, as_of_date)
);

-- ===================== API access control =====================
CREATE TABLE IF NOT EXISTS api_keys (
    id SERIAL PRIMARY KEY,
    key_value VARCHAR(64) UNIQUE NOT NULL,
    tier VARCHAR(20) NOT NULL DEFAULT 'free',   -- free, premium, pro, unlimited
    is_readonly BOOLEAN NOT NULL DEFAULT true,
    daily_limit INTEGER NOT NULL DEFAULT 100,
    owner_email VARCHAR(200),
    created_at TIMESTAMP NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS api_usage_log (
    id BIGSERIAL PRIMARY KEY,
    api_key_id INTEGER NOT NULL REFERENCES api_keys(id),
    endpoint VARCHAR(200) NOT NULL,
    called_at TIMESTAMP NOT NULL DEFAULT now(),
    status_code INTEGER
);

CREATE INDEX IF NOT EXISTS idx_usage_key_date ON api_usage_log(api_key_id, called_at);
